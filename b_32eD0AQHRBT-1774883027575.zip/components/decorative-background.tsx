"use client"

export function DecorativeBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Base gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#fdf6ed] via-[#fef9f3] to-[#fff5e6]" />
      
      {/* Organic blob shapes */}
      <svg 
        className="absolute top-0 left-0 w-full h-full" 
        viewBox="0 0 1440 900" 
        preserveAspectRatio="xMidYMid slice"
        fill="none"
      >
        {/* Top left blob */}
        <path 
          d="M-100 0C-50 80 30 150 80 200C130 250 100 350 50 400C0 450 -80 400 -100 350V0Z" 
          fill="#f5e6d3" 
          opacity="0.6"
        />
        
        {/* Top right blob */}
        <path 
          d="M1300 -50C1380 0 1450 100 1440 180C1430 260 1350 300 1280 280C1210 260 1180 180 1200 100C1220 20 1260 -50 1300 -50Z" 
          fill="#fce5c8" 
          opacity="0.5"
        />
        
        {/* Bottom left blob */}
        <path 
          d="M-50 700C30 650 120 680 180 750C240 820 200 900 120 900H-50V700Z" 
          fill="#f5dfc8" 
          opacity="0.6"
        />
        
        {/* Bottom right blob */}
        <path 
          d="M1200 800C1280 750 1380 780 1440 850V900H1150C1150 850 1180 820 1200 800Z" 
          fill="#fce5c8" 
          opacity="0.5"
        />
        
        {/* Center accent blob */}
        <ellipse 
          cx="1350" 
          cy="450" 
          rx="120" 
          ry="200" 
          fill="#f8e8d6" 
          opacity="0.4"
        />
      </svg>
      
      {/* Food doodles */}
      <svg 
        className="absolute top-0 left-0 w-full h-full" 
        viewBox="0 0 1440 900" 
        preserveAspectRatio="xMidYMid slice"
        fill="none"
        stroke="#c4a574"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {/* Burger doodle - top left */}
        <g transform="translate(80, 60)" opacity="0.6">
          <ellipse cx="30" cy="10" rx="28" ry="10" />
          <path d="M5 15 Q30 25 55 15" />
          <path d="M8 22 L52 22" />
          <ellipse cx="30" cy="30" rx="25" ry="8" />
        </g>
        
        {/* Pizza slice - top right */}
        <g transform="translate(1280, 80)" opacity="0.6">
          <path d="M0 40 L25 0 L50 40 Z" />
          <ellipse cx="20" cy="25" rx="5" ry="5" />
          <ellipse cx="35" cy="30" rx="4" ry="4" />
          <ellipse cx="25" cy="35" rx="3" ry="3" />
        </g>
        
        {/* Leaf doodle - left side */}
        <g transform="translate(50, 300)" opacity="0.5">
          <path d="M15 0 Q0 15 15 30 Q30 15 15 0" />
          <path d="M15 5 L15 25" />
        </g>
        
        {/* Apple doodle - right side */}
        <g transform="translate(1350, 250)" opacity="0.5">
          <path d="M20 8 Q25 0 30 5" />
          <path d="M10 15 Q0 30 15 45 Q25 50 35 45 Q50 30 40 15 Q35 8 25 10 Q15 8 10 15" />
        </g>
        
        {/* Bread/croissant - bottom left */}
        <g transform="translate(120, 780)" opacity="0.5">
          <path d="M0 20 Q10 0 30 5 Q50 0 60 20 Q55 35 30 30 Q5 35 0 20" />
          <path d="M15 15 Q30 20 45 15" />
        </g>
        
        {/* Bowl/plate doodle - bottom right */}
        <g transform="translate(1250, 800)" opacity="0.5">
          <ellipse cx="30" cy="15" rx="30" ry="10" />
          <path d="M5 15 Q10 35 30 40 Q50 35 55 15" />
        </g>
        
        {/* Carrot doodle - middle left */}
        <g transform="translate(30, 500)" opacity="0.4">
          <path d="M20 0 L25 5 L15 5 Z" />
          <path d="M20 5 Q25 20 20 40 Q15 20 20 5" />
          <path d="M18 15 L22 15" />
          <path d="M17 25 L23 25" />
        </g>
        
        {/* Fork doodle - top center */}
        <g transform="translate(600, 30)" opacity="0.4">
          <path d="M10 0 L10 20 M15 0 L15 20 M20 0 L20 20" />
          <path d="M10 20 Q15 25 15 35" />
        </g>
        
        {/* Spoon doodle */}
        <g transform="translate(1380, 600)" opacity="0.4">
          <ellipse cx="10" cy="10" rx="8" ry="10" />
          <path d="M10 20 L10 45" />
        </g>
        
        {/* Small decorative circles */}
        <circle cx="200" cy="150" r="3" fill="#c4a574" stroke="none" opacity="0.3" />
        <circle cx="1300" cy="350" r="4" fill="#c4a574" stroke="none" opacity="0.3" />
        <circle cx="100" cy="650" r="3" fill="#c4a574" stroke="none" opacity="0.3" />
        <circle cx="1380" cy="150" r="5" fill="#c4a574" stroke="none" opacity="0.3" />
        <circle cx="850" cy="850" r="4" fill="#c4a574" stroke="none" opacity="0.3" />
        
        {/* Dotted decorative elements */}
        <circle cx="180" cy="400" r="2" fill="#c4a574" stroke="none" opacity="0.4" />
        <circle cx="1320" cy="500" r="2" fill="#c4a574" stroke="none" opacity="0.4" />
      </svg>
    </div>
  )
}
