"use client"

import { useState } from "react"
import { Copy, Check, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"

interface OTPDisplayProps {
  otp: string
  label: string
  description?: string
}

export function OTPDisplay({ otp, label, description }: OTPDisplayProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    navigator.clipboard.writeText(otp)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl">
      <div className="flex items-center gap-2 mb-2">
        <Shield className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium text-primary">{label}</span>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {otp.split("").map((digit, index) => (
            <div
              key={index}
              className="w-10 h-12 bg-card border-2 border-primary/30 rounded-lg flex items-center justify-center text-xl font-bold text-foreground"
            >
              {digit}
            </div>
          ))}
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={handleCopy}
          className="text-primary hover:text-primary/80"
        >
          {copied ? (
            <>
              <Check className="h-4 w-4 mr-1" />
              Copied
            </>
          ) : (
            <>
              <Copy className="h-4 w-4 mr-1" />
              Copy
            </>
          )}
        </Button>
      </div>
      
      {description && (
        <p className="text-xs text-muted-foreground mt-2">{description}</p>
      )}
    </div>
  )
}
