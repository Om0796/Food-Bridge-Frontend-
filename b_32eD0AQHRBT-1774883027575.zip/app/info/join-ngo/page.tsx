"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Building2, Users, ClipboardList, BarChart3, CheckCircle, ArrowRight, Shield } from "lucide-react"
import Link from "next/link"

const benefits = [
  {
    icon: Building2,
    title: "Regular Food Supply",
    description: "Get consistent access to surplus food from verified donors in your area."
  },
  {
    icon: ClipboardList,
    title: "Easy Management",
    description: "Track all incoming donations and distributions through our simple dashboard."
  },
  {
    icon: Shield,
    title: "Verified Network",
    description: "Connect with pre-verified donors ensuring quality and safety of food."
  },
  {
    icon: BarChart3,
    title: "Impact Reports",
    description: "Generate detailed reports showcasing your organization's impact."
  }
]

const requirements = [
  "Valid NGO/Trust registration certificate",
  "Operational for at least 6 months",
  "Proper food storage facilities",
  "Dedicated contact person",
  "Commitment to food safety standards"
]

const features = [
  {
    title: "Real-time Notifications",
    description: "Get instant alerts when food donations become available near you."
  },
  {
    title: "Claim System",
    description: "Easily claim available donations with a single click."
  },
  {
    title: "Delivery Tracking",
    description: "Track food deliveries from pickup to your doorstep."
  },
  {
    title: "OTP Verification",
    description: "Secure handover with OTP-based verification system."
  }
]

export default function JoinNGOInfoPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/20 rounded-full mb-6">
              <Building2 className="h-4 w-4 text-accent" />
              <span className="text-sm font-medium text-accent">Join as NGO / Trust</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Receive Food for<br />Your Community
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Partner with AnajSetu to receive surplus food from restaurants, hotels, and individuals. 
              Help us ensure no one in your community goes hungry.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center border-2 hover:border-accent/50 transition-colors">
                <CardContent className="pt-8 pb-6">
                  <div className="w-14 h-14 bg-accent/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">Requirements to Join</h2>
              <div className="space-y-3">
                {requirements.map((req, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-accent shrink-0" />
                    <span className="text-foreground">{req}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">Platform Features</h2>
              <div className="space-y-4">
                {features.map((feature, index) => (
                  <div key={index} className="bg-muted/50 rounded-xl p-4">
                    <h4 className="font-medium text-foreground mb-1">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="text-center bg-accent/10 rounded-3xl p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Join Our Network of 200+ NGOs
            </h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              Register your organization today and start receiving food donations 
              to help your community thrive.
            </p>
            <Link href="/register/trust">
              <Button size="lg" className="gap-2 bg-accent text-accent-foreground hover:bg-accent/90">
                Register Your NGO <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
