"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Truck, Clock, Wallet, MapPin, CheckCircle, ArrowRight, Smartphone } from "lucide-react"
import Link from "next/link"

const benefits = [
  {
    icon: Clock,
    title: "Flexible Hours",
    description: "Work on your own schedule. Accept deliveries when it suits you."
  },
  {
    icon: Wallet,
    title: "Earn Per Delivery",
    description: "Get paid for every successful delivery. More deliveries, more earnings."
  },
  {
    icon: MapPin,
    title: "Local Deliveries",
    description: "Deliver within your preferred area. No long-distance requirements."
  },
  {
    icon: Smartphone,
    title: "Easy App Interface",
    description: "Simple and intuitive dashboard to manage all your deliveries."
  }
]

const requirements = [
  "Valid driving license (for motorized vehicles)",
  "Government-issued ID proof",
  "Smartphone with internet access",
  "Own vehicle (bike, scooter, or car)",
  "Age 18 or above"
]

const howItWorks = [
  {
    step: 1,
    title: "Get Notified",
    description: "Receive pickup requests from nearby donors on your dashboard."
  },
  {
    step: 2,
    title: "Accept & Pickup",
    description: "Accept the request, navigate to donor, verify with OTP, and collect food."
  },
  {
    step: 3,
    title: "Deliver & Verify",
    description: "Deliver to the NGO/Trust, verify handover with OTP, complete delivery."
  },
  {
    step: 4,
    title: "Get Paid",
    description: "Receive payment for completed delivery directly to your account."
  }
]

export default function DeliveryPartnerInfoPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-foreground/10 rounded-full mb-6">
              <Truck className="h-4 w-4 text-foreground" />
              <span className="text-sm font-medium text-foreground">Delivery Partner</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Deliver Hope,<br />Earn While You Help
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Join our delivery network and become the vital link between surplus food and hungry families. 
              Earn money while making a meaningful impact in your community.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center border-2 hover:border-foreground/30 transition-colors">
                <CardContent className="pt-8 pb-6">
                  <div className="w-14 h-14 bg-foreground/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="h-7 w-7 text-foreground" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mb-16">
            <h2 className="text-2xl font-bold text-foreground mb-8 text-center">How Delivery Works</h2>
            <div className="grid md:grid-cols-4 gap-6">
              {howItWorks.map((item) => (
                <div key={item.step} className="text-center relative">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-primary-foreground font-bold">{item.step}</span>
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                  {item.step < 4 && (
                    <div className="hidden md:block absolute top-6 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-border" />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">Requirements to Join</h2>
              <div className="space-y-3">
                {requirements.map((req, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0" />
                    <span className="text-foreground">{req}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-muted/50 rounded-3xl p-8">
              <h3 className="text-xl font-bold text-foreground mb-4">Earning Potential</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Per delivery</span>
                  <span className="font-semibold text-foreground">Rs. 50 - 100</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Average daily (5 deliveries)</span>
                  <span className="font-semibold text-foreground">Rs. 250 - 500</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Monthly potential</span>
                  <span className="font-semibold text-foreground">Rs. 7,500 - 15,000</span>
                </div>
                <p className="text-xs text-muted-foreground pt-2 border-t border-border">
                  *Earnings depend on number of deliveries and distance
                </p>
              </div>
            </div>
          </div>

          <div className="text-center bg-foreground rounded-3xl p-8 md:p-12 text-primary-foreground">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">
              Start Delivering Today
            </h2>
            <p className="text-primary-foreground/80 mb-6 max-w-xl mx-auto">
              Join 500+ delivery partners already making a difference. 
              Sign up now and start earning while helping your community.
            </p>
            <Link href="/register/delivery">
              <Button size="lg" variant="secondary" className="gap-2">
                Register as Delivery Partner <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
