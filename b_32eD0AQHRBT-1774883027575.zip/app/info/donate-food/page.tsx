"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Heart, Clock, Shield, Award, CheckCircle, ArrowRight } from "lucide-react"
import Link from "next/link"

const benefits = [
  {
    icon: Heart,
    title: "Feed the Hungry",
    description: "Your surplus food directly reaches families and individuals who need it most."
  },
  {
    icon: Clock,
    title: "Quick Pickup",
    description: "Our delivery partners pick up food within hours of your donation request."
  },
  {
    icon: Shield,
    title: "Safe & Hygienic",
    description: "We ensure proper handling and transportation to maintain food safety standards."
  },
  {
    icon: Award,
    title: "CSR Certificates",
    description: "Receive official certificates for your corporate social responsibility records."
  }
]

const steps = [
  "Register as a donor on AnajSetu",
  "List your surplus food with details",
  "Our system matches you with nearby NGOs",
  "Delivery partner picks up the food",
  "Food reaches those in need"
]

const foodTypes = [
  "Cooked meals from restaurants/hotels",
  "Packaged food items",
  "Fresh fruits and vegetables",
  "Bakery products",
  "Catering leftovers",
  "Event surplus food"
]

export default function DonateFoodInfoPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-24 pb-16 md:pt-32 md:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-6">
              <Heart className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-primary">Donate Food</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              Share Your Surplus,<br />Feed a Soul
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Every day, tons of perfectly good food goes to waste while millions go hungry. 
              Join AnajSetu to bridge this gap and make every meal count.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="text-center border-2 hover:border-primary/50 transition-colors">
                <CardContent className="pt-8 pb-6">
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">How to Donate Food</h2>
              <div className="space-y-4">
                {steps.map((step, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center shrink-0">
                      <span className="text-primary-foreground font-bold text-sm">{index + 1}</span>
                    </div>
                    <span className="text-foreground">{step}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">What Can You Donate?</h2>
              <div className="space-y-3">
                {foodTypes.map((type, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0" />
                    <span className="text-foreground">{type}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="text-center bg-primary/5 rounded-3xl p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Ready to Make a Difference?
            </h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              Join thousands of donors who are already helping feed the hungry. 
              Register now and start your journey of giving.
            </p>
            <Link href="/register/donor">
              <Button size="lg" className="gap-2">
                Register as Donor <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
