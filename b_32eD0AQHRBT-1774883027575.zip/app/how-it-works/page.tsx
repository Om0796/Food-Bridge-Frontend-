"use client"

import { useState, useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, ClipboardList, MapPin, Truck, CheckCircle, Shield, Clock, Heart } from "lucide-react"
import Link from "next/link"

const slides = [
  {
    id: 1,
    title: "Register & List Food",
    description: "Donors register on AnajSetu and list available surplus food with details like quantity, type, expiry, and pickup location. Our intuitive interface makes it easy to donate in minutes.",
    icon: ClipboardList,
    color: "bg-primary",
    features: ["Quick registration process", "Easy food listing form", "Photo upload support", "Flexible pickup timing"]
  },
  {
    id: 2,
    title: "Smart Matching",
    description: "Our intelligent system automatically matches donors with nearby NGOs and trusts based on location, food type, and quantity. This ensures efficient distribution and minimal food waste.",
    icon: MapPin,
    color: "bg-accent",
    features: ["Location-based matching", "Real-time availability", "Priority to nearest NGOs", "Instant notifications"]
  },
  {
    id: 3,
    title: "Secure Pickup",
    description: "Verified delivery partners pick up food from donors. OTP verification ensures secure handover. Donors can track the entire process from pickup to delivery.",
    icon: Truck,
    color: "bg-foreground",
    features: ["Verified delivery partners", "OTP-based verification", "Real-time tracking", "Safe food handling"]
  },
  {
    id: 4,
    title: "Impact & Certification",
    description: "Track your contributions, see the real impact of your donations, and receive CSR certificates. Every meal donated is a step towards a hunger-free world.",
    icon: CheckCircle,
    color: "bg-primary",
    features: ["Impact dashboard", "CSR certificates", "Donation history", "Community recognition"]
  }
]

const values = [
  {
    icon: Shield,
    title: "Food Safety",
    description: "We maintain strict food safety standards throughout the donation and delivery process."
  },
  {
    icon: Clock,
    title: "Time Efficiency",
    description: "Quick turnaround from donation to delivery ensures food reaches people while still fresh."
  },
  {
    icon: Heart,
    title: "Community First",
    description: "Every decision we make prioritizes the well-being of communities we serve."
  }
]

export default function HowItWorksPage() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  useEffect(() => {
    if (!isAutoPlaying) return
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [isAutoPlaying])

  const nextSlide = () => {
    setIsAutoPlaying(false)
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setIsAutoPlaying(false)
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  const goToSlide = (index: number) => {
    setIsAutoPlaying(false)
    setCurrentSlide(index)
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <section className="pt-24 pb-16 md:pt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 text-balance">
              How AnajSetu Works
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              A simple, transparent, and efficient process to connect surplus food with those who need it most.
            </p>
          </div>

          {/* Image Slider */}
          <div className="relative max-w-4xl mx-auto mb-16">
            <div className="overflow-hidden rounded-3xl bg-card border border-border shadow-xl">
              <div 
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentSlide * 100}%)` }}
              >
                {slides.map((slide) => (
                  <div key={slide.id} className="w-full shrink-0">
                    <div className="grid md:grid-cols-2 min-h-[400px]">
                      <div className={`${slide.color} p-8 md:p-12 flex flex-col justify-center`}>
                        <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
                          <slide.icon className="h-8 w-8 text-white" />
                        </div>
                        <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                          {slide.title}
                        </h2>
                        <p className="text-white/90 leading-relaxed">
                          {slide.description}
                        </p>
                      </div>
                      <div className="p-8 md:p-12 flex flex-col justify-center bg-card">
                        <h3 className="font-semibold text-foreground mb-4">Key Features</h3>
                        <ul className="space-y-3">
                          {slide.features.map((feature, idx) => (
                            <li key={idx} className="flex items-center gap-3">
                              <CheckCircle className="h-5 w-5 text-primary shrink-0" />
                              <span className="text-foreground">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation Arrows */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-background transition-colors"
              aria-label="Previous slide"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg hover:bg-background transition-colors"
              aria-label="Next slide"
            >
              <ChevronRight className="h-5 w-5" />
            </button>

            {/* Dots */}
            <div className="flex justify-center gap-2 mt-6">
              {slides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentSlide ? "bg-primary" : "bg-muted hover:bg-muted-foreground/50"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>

          {/* Step Numbers */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                onClick={() => goToSlide(index)}
                className={`text-left p-6 rounded-2xl border-2 transition-all ${
                  index === currentSlide 
                    ? "border-primary bg-primary/5" 
                    : "border-border hover:border-primary/50"
                }`}
              >
                <div className={`w-10 h-10 ${slide.color} rounded-xl flex items-center justify-center mb-3`}>
                  <span className="text-white font-bold">{index + 1}</span>
                </div>
                <h3 className="font-semibold text-foreground">{slide.title}</h3>
              </button>
            ))}
          </div>

          {/* Our Values */}
          <div className="bg-muted/50 rounded-3xl p-8 md:p-12 mb-16">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8 text-center">
              Our Core Values
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {values.map((value) => (
                <div key={value.title} className="text-center">
                  <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <value.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <div className="text-center">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
              Choose how you want to contribute and join the movement against food waste and hunger.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register/donor">
                <Button size="lg">Donate Food</Button>
              </Link>
              <Link href="/register/trust">
                <Button size="lg" variant="outline">Join as NGO</Button>
              </Link>
              <Link href="/register/delivery">
                <Button size="lg" variant="outline">Become Delivery Partner</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
