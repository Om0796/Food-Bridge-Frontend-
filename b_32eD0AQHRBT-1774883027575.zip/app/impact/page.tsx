"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, ResponsiveContainer, Legend, AreaChart, Area
} from "recharts"
import { TrendingUp, Users, Utensils, Award, Building2, Truck } from "lucide-react"

// Chart colors - Black and Yellow theme
const COLORS = {
  yellow: "#FBBF24",
  gold: "#F59E0B", 
  amber: "#D97706",
  black: "#171717",
  darkGray: "#262626",
  gray: "#404040"
}

// Monthly meals data
const mealsData = [
  { month: "Jan", meals: 3200 },
  { month: "Feb", meals: 3800 },
  { month: "Mar", meals: 4200 },
  { month: "Apr", meals: 4800 },
  { month: "May", meals: 5200 },
  { month: "Jun", meals: 5800 },
  { month: "Jul", meals: 6200 },
  { month: "Aug", meals: 6800 },
  { month: "Sep", meals: 7200 },
  { month: "Oct", meals: 7800 },
  { month: "Nov", meals: 8200 },
  { month: "Dec", meals: 8800 }
]

// Food waste prevention data
const wasteData = [
  { month: "Jan", prevented: 420, landfill: 80 },
  { month: "Feb", prevented: 480, landfill: 70 },
  { month: "Mar", prevented: 560, landfill: 60 },
  { month: "Apr", prevented: 620, landfill: 55 },
  { month: "May", prevented: 700, landfill: 50 },
  { month: "Jun", prevented: 780, landfill: 45 }
]

// Distribution by region
const regionData = [
  { name: "North", value: 35 },
  { name: "South", value: 25 },
  { name: "East", value: 20 },
  { name: "West", value: 20 }
]

// Growth data
const growthData = [
  { year: "2021", donors: 50, ngos: 20, deliveries: 500 },
  { year: "2022", donors: 150, ngos: 60, deliveries: 2000 },
  { year: "2023", donors: 350, ngos: 120, deliveries: 8000 },
  { year: "2024", donors: 500, ngos: 200, deliveries: 15000 }
]

const stats = [
  { icon: Utensils, value: "50,000+", label: "Meals Distributed", trend: "+24% this month" },
  { icon: Users, value: "500+", label: "Active Donors", trend: "+18% this month" },
  { icon: Building2, value: "200+", label: "Partner NGOs", trend: "+12% this month" },
  { icon: Truck, value: "15,000+", label: "Deliveries Completed", trend: "+32% this month" },
  { icon: TrendingUp, value: "10,000 kg", label: "Food Waste Prevented", trend: "+28% this month" },
  { icon: Award, value: "500+", label: "CSR Certificates Issued", trend: "+15% this month" }
]

export default function ImpactPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero Section - Black & Yellow */}
      <section className="pt-24 pb-16 md:pt-32 md:pb-24 bg-neutral-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Our Impact <span className="text-amber-400">So Far</span>
            </h1>
            <p className="text-lg text-neutral-300 max-w-2xl mx-auto leading-relaxed">
              Every number represents a life touched, a meal saved, and a step towards 
              eliminating hunger. See the difference we are making together.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="bg-neutral-800 rounded-2xl p-6 border border-neutral-700">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-400/20 rounded-xl flex items-center justify-center">
                    <stat.icon className="h-6 w-6 text-amber-400" />
                  </div>
                  <div>
                    <div className="text-2xl md:text-3xl font-bold text-white">{stat.value}</div>
                    <div className="text-neutral-400">{stat.label}</div>
                  </div>
                </div>
                <div className="mt-4 text-sm text-amber-400 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  {stat.trend}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Charts Section */}
      <section className="py-16 md:py-24 bg-neutral-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            
            {/* Meals Delivered Chart */}
            <Card className="bg-neutral-900 border-neutral-800">
              <CardHeader>
                <CardTitle className="text-white">Meals Delivered Monthly</CardTitle>
                <CardDescription className="text-neutral-400">
                  Number of meals distributed each month in 2024
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    meals: { label: "Meals", color: COLORS.yellow }
                  }}
                  className="h-[300px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={mealsData}>
                      <defs>
                        <linearGradient id="mealsGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor={COLORS.yellow} stopOpacity={0.4}/>
                          <stop offset="95%" stopColor={COLORS.yellow} stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#404040" />
                      <XAxis dataKey="month" stroke="#737373" />
                      <YAxis stroke="#737373" />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Area 
                        type="monotone" 
                        dataKey="meals" 
                        stroke={COLORS.yellow} 
                        strokeWidth={2}
                        fill="url(#mealsGradient)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            {/* Food Waste Prevention */}
            <Card className="bg-neutral-900 border-neutral-800">
              <CardHeader>
                <CardTitle className="text-white">Food Waste Prevention (kg)</CardTitle>
                <CardDescription className="text-neutral-400">
                  Food saved vs. what would have gone to landfill
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    prevented: { label: "Prevented", color: COLORS.yellow },
                    landfill: { label: "Would be Landfill", color: COLORS.darkGray }
                  }}
                  className="h-[300px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={wasteData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#404040" />
                      <XAxis dataKey="month" stroke="#737373" />
                      <YAxis stroke="#737373" />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Bar dataKey="prevented" fill={COLORS.yellow} radius={[4, 4, 0, 0]} name="Food Saved" />
                      <Bar dataKey="landfill" fill={COLORS.darkGray} radius={[4, 4, 0, 0]} name="Potential Waste" />
                    </BarChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            {/* Regional Distribution */}
            <Card className="bg-neutral-900 border-neutral-800">
              <CardHeader>
                <CardTitle className="text-white">Distribution by Region</CardTitle>
                <CardDescription className="text-neutral-400">
                  Percentage of meals distributed across regions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    value: { label: "Distribution" }
                  }}
                  className="h-[300px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={regionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {regionData.map((_, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={[COLORS.yellow, COLORS.gold, COLORS.amber, COLORS.darkGray][index]} 
                          />
                        ))}
                      </Pie>
                      <ChartTooltip content={<ChartTooltipContent />} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>

            {/* Growth Over Years */}
            <Card className="bg-neutral-900 border-neutral-800">
              <CardHeader>
                <CardTitle className="text-white">Platform Growth</CardTitle>
                <CardDescription className="text-neutral-400">
                  Year-over-year growth in donors, NGOs, and deliveries
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    donors: { label: "Donors", color: COLORS.yellow },
                    ngos: { label: "NGOs", color: COLORS.gold },
                    deliveries: { label: "Deliveries", color: COLORS.amber }
                  }}
                  className="h-[300px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={growthData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#404040" />
                      <XAxis dataKey="year" stroke="#737373" />
                      <YAxis stroke="#737373" />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="donors" 
                        stroke={COLORS.yellow} 
                        strokeWidth={2}
                        dot={{ fill: COLORS.yellow }}
                        name="Donors"
                      />
                      <Line 
                        type="monotone" 
                        dataKey="ngos" 
                        stroke={COLORS.gold} 
                        strokeWidth={2}
                        dot={{ fill: COLORS.gold }}
                        name="NGOs"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>

          {/* Call to Action */}
          <div className="mt-16 text-center bg-gradient-to-r from-amber-500 to-yellow-400 rounded-3xl p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-bold text-neutral-900 mb-4">
              Be Part of Our Growing Impact
            </h2>
            <p className="text-neutral-800 mb-6 max-w-xl mx-auto">
              Join thousands of donors, NGOs, and delivery partners who are already 
              making a difference. Every contribution counts.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/register/donor" 
                className="inline-flex items-center justify-center px-6 py-3 bg-neutral-900 text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors"
              >
                Start Donating
              </a>
              <a 
                href="/register/trust" 
                className="inline-flex items-center justify-center px-6 py-3 bg-white text-neutral-900 rounded-lg font-medium hover:bg-neutral-100 transition-colors"
              >
                Register Your NGO
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
