"use client"

import { useState } from "react"
import Link from "next/link"
import { Truck, MapPin, Package, Wallet, Bell, Settings, LogOut, Navigation, Phone, CheckCircle, Shield, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { OTPInput } from "@/components/otp-input"

const pendingPickups = [
  {
    id: 1,
    donor: "Grand Hotel",
    donorAddress: "123 Main Street, Downtown",
    recipient: "Hope Foundation",
    recipientAddress: "456 Oak Avenue, East Side",
    type: "Biryani",
    quantity: "50 meals",
    distance: "4.2 km",
    payment: "Rs. 150",
    status: "pending",
    pickupOtp: "4829",
    deliveryOtp: "5927"
  },
  {
    id: 2,
    donor: "City Restaurant",
    donorAddress: "789 Food Lane, Central",
    recipient: "Care Trust",
    recipientAddress: "321 Help Street, West Side",
    type: "Rice & Curry",
    quantity: "30 meals",
    distance: "2.8 km",
    payment: "Rs. 100",
    status: "pending",
    pickupOtp: "7163",
    deliveryOtp: "3841"
  }
]

export default function DeliveryDashboard() {
  const [activePickup, setActivePickup] = useState<typeof pendingPickups[0] | null>(null)
  const [pickupStage, setPickupStage] = useState<"select" | "pickup" | "verify-pickup" | "deliver" | "verify-delivery" | "complete">("select")
  const [sliderValue, setSliderValue] = useState(0)
  const [otpError, setOtpError] = useState(false)
  const [verifyingOtp, setVerifyingOtp] = useState(false)

  const handleAcceptPickup = (pickup: typeof pendingPickups[0]) => {
    setActivePickup(pickup)
    setPickupStage("pickup")
  }

  const handleSlideConfirm = () => {
    if (sliderValue >= 90) {
      if (pickupStage === "pickup") {
        setPickupStage("verify-pickup")
        setSliderValue(0)
      } else if (pickupStage === "deliver") {
        setPickupStage("verify-delivery")
        setSliderValue(0)
      }
    }
  }

  const handleOtpComplete = (otp: string, expectedOtp: string, nextStage: "deliver" | "complete") => {
    setVerifyingOtp(true)
    
    // Simulate OTP verification
    setTimeout(() => {
      if (otp === expectedOtp) {
        setOtpError(false)
        setPickupStage(nextStage)
      } else {
        setOtpError(true)
      }
      setVerifyingOtp(false)
    }, 1000)
  }

  const handleNextPickup = () => {
    setActivePickup(null)
    setPickupStage("select")
    setSliderValue(0)
    setOtpError(false)
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-card border-r border-border hidden lg:block">
        <div className="p-6">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">AS</span>
            </div>
            <span className="font-bold text-lg text-foreground">AnajSetu</span>
          </Link>
        </div>

        <nav className="px-4 space-y-2">
          <Link href="/dashboard/delivery" className="flex items-center gap-3 px-4 py-3 rounded-lg bg-primary/10 text-primary">
            <Truck className="h-5 w-5" />
            Dashboard
          </Link>
          <Link href="/dashboard/delivery/pickups" className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-muted transition-colors">
            <Package className="h-5 w-5" />
            My Pickups
          </Link>
          <Link href="/dashboard/delivery/earnings" className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-muted transition-colors">
            <Wallet className="h-5 w-5" />
            Earnings
          </Link>
          <Link href="/dashboard/delivery/map" className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-muted transition-colors">
            <MapPin className="h-5 w-5" />
            Live Map
          </Link>
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border">
          <div className="flex items-center gap-3 px-4 py-2">
            <div className="w-10 h-10 bg-foreground/10 rounded-full flex items-center justify-center">
              <Truck className="h-5 w-5 text-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-foreground truncate">Rahul Kumar</p>
              <p className="text-xs text-muted-foreground">Delivery Partner</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between sticky top-0 z-10">
          <div>
            <h1 className="text-xl font-bold text-foreground">Delivery Dashboard</h1>
            <p className="text-sm text-muted-foreground">Welcome back, Rahul</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-primary/10 text-primary">Online</Badge>
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/">
              <Button variant="ghost" size="icon">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </header>

        <div className="p-6">
          {/* Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Today&apos;s Deliveries</p>
                    <p className="text-2xl font-bold text-foreground">8</p>
                    <p className="text-xs text-muted-foreground">completed</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Package className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Today&apos;s Earnings</p>
                    <p className="text-2xl font-bold text-foreground">Rs. 850</p>
                    <p className="text-xs text-muted-foreground">earned</p>
                  </div>
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                    <Wallet className="h-6 w-6 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Distance</p>
                    <p className="text-2xl font-bold text-foreground">24.5 km</p>
                    <p className="text-xs text-muted-foreground">traveled</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Navigation className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Rating</p>
                    <p className="text-2xl font-bold text-foreground">4.8</p>
                    <p className="text-xs text-muted-foreground">out of 5</p>
                  </div>
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Active Pickup or Map View */}
          {activePickup ? (
            <Card className="mb-8">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>
                      {pickupStage === "pickup" && "Pickup Location"}
                      {pickupStage === "verify-pickup" && "Verify Pickup OTP"}
                      {pickupStage === "deliver" && "Delivery Location"}
                      {pickupStage === "verify-delivery" && "Verify Delivery OTP"}
                      {pickupStage === "complete" && "Delivery Complete"}
                    </CardTitle>
                    <CardDescription>
                      {pickupStage === "pickup" && `Pick up from ${activePickup.donor}`}
                      {pickupStage === "verify-pickup" && `Ask ${activePickup.donor} for the pickup OTP`}
                      {pickupStage === "deliver" && `Deliver to ${activePickup.recipient}`}
                      {pickupStage === "verify-delivery" && `Ask ${activePickup.recipient} for the delivery OTP`}
                      {pickupStage === "complete" && "Great job! Delivery completed successfully."}
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">
                    {activePickup.payment}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {/* OTP Verification Screens */}
                {(pickupStage === "verify-pickup" || pickupStage === "verify-delivery") ? (
                  <div className="py-8">
                    <div className="max-w-sm mx-auto text-center">
                      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Shield className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-foreground mb-2">
                        {pickupStage === "verify-pickup" ? "Enter Pickup OTP" : "Enter Delivery OTP"}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-6">
                        {pickupStage === "verify-pickup" 
                          ? `Ask the donor (${activePickup.donor}) for the 4-digit OTP to confirm pickup`
                          : `Ask the receiver (${activePickup.recipient}) for the 4-digit OTP to confirm delivery`
                        }
                      </p>
                      
                      <div className="mb-6">
                        <OTPInput
                          length={4}
                          onComplete={(otp) => handleOtpComplete(
                            otp, 
                            pickupStage === "verify-pickup" ? activePickup.pickupOtp : activePickup.deliveryOtp,
                            pickupStage === "verify-pickup" ? "deliver" : "complete"
                          )}
                          disabled={verifyingOtp}
                        />
                      </div>

                      {otpError && (
                        <div className="flex items-center justify-center gap-2 text-destructive mb-4">
                          <AlertCircle className="h-4 w-4" />
                          <span className="text-sm">Incorrect OTP. Please try again.</span>
                        </div>
                      )}

                      {verifyingOtp && (
                        <p className="text-sm text-muted-foreground">Verifying OTP...</p>
                      )}

                      <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                        <p className="text-xs text-muted-foreground">
                          Contact for help:
                        </p>
                        <Button size="sm" variant="outline" className="mt-2">
                          <Phone className="h-4 w-4 mr-1" />
                          {pickupStage === "verify-pickup" ? "Call Donor" : "Call Receiver"}
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : pickupStage !== "complete" ? (
                  <>
                    {/* Map Placeholder */}
                    <div className="bg-muted rounded-xl h-64 mb-6 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5" />
                      <div className="text-center relative z-10">
                        <MapPin className="h-12 w-12 text-primary mx-auto mb-2" />
                        <p className="font-medium text-foreground">
                          {pickupStage === "pickup" ? activePickup.donorAddress : activePickup.recipientAddress}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">{activePickup.distance} away</p>
                      </div>
                      {/* Decorative map lines */}
                      <div className="absolute inset-0 opacity-20">
                        <div className="absolute top-1/4 left-0 right-0 h-px bg-border" />
                        <div className="absolute top-2/4 left-0 right-0 h-px bg-border" />
                        <div className="absolute top-3/4 left-0 right-0 h-px bg-border" />
                        <div className="absolute left-1/4 top-0 bottom-0 w-px bg-border" />
                        <div className="absolute left-2/4 top-0 bottom-0 w-px bg-border" />
                        <div className="absolute left-3/4 top-0 bottom-0 w-px bg-border" />
                      </div>
                    </div>

                    {/* Location Details */}
                    <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg mb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <MapPin className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">
                            {pickupStage === "pickup" ? activePickup.donor : activePickup.recipient}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {pickupStage === "pickup" ? activePickup.donorAddress : activePickup.recipientAddress}
                          </p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        <Phone className="h-4 w-4 mr-1" /> Call
                      </Button>
                    </div>

                    {/* Food Details */}
                    <div className="p-4 bg-muted/50 rounded-lg mb-6">
                      <p className="text-sm text-muted-foreground mb-1">Package Details</p>
                      <p className="font-medium text-foreground">{activePickup.type} - {activePickup.quantity}</p>
                    </div>

                    {/* OTP Info Banner */}
                    <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg mb-6">
                      <div className="flex items-center gap-2 mb-1">
                        <Shield className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium text-primary">OTP Verification Required</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {pickupStage === "pickup" 
                          ? "After reaching the pickup location, you will need to enter the OTP provided by the donor to confirm pickup."
                          : "After reaching the delivery location, you will need to enter the OTP provided by the receiver to confirm delivery."
                        }
                      </p>
                    </div>

                    {/* Slide to Confirm */}
                    <div className="relative">
                      <div className="bg-primary/10 rounded-full h-14 relative overflow-hidden">
                        <div 
                          className="absolute left-0 top-0 bottom-0 bg-primary rounded-full transition-all"
                          style={{ width: `${sliderValue}%` }}
                        />
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={sliderValue}
                          onChange={(e) => setSliderValue(Number(e.target.value))}
                          onMouseUp={handleSlideConfirm}
                          onTouchEnd={handleSlideConfirm}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <span className="font-medium text-foreground">
                            {pickupStage === "pickup" ? "Slide to Reach Pickup" : "Slide to Reach Delivery"}
                          </span>
                        </div>
                        <div 
                          className="absolute top-1 bottom-1 w-12 bg-primary-foreground rounded-full flex items-center justify-center shadow-md pointer-events-none transition-all"
                          style={{ left: `calc(${sliderValue}% - ${sliderValue * 0.12}px)` }}
                        >
                          <Navigation className="h-5 w-5 text-primary" />
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="h-10 w-10 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Delivery Completed!</h3>
                    <p className="text-muted-foreground mb-4">You earned {activePickup.payment} for this delivery.</p>
                    
                    <div className="flex items-center justify-center gap-2 text-primary mb-4">
                      <Shield className="h-5 w-5" />
                      <span className="text-sm font-medium">Both OTPs verified successfully</span>
                    </div>

                    <div className="p-4 bg-muted/50 rounded-lg mb-6 max-w-sm mx-auto">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Amount Received:</span>
                        <span className="font-bold text-foreground">{activePickup.payment}</span>
                      </div>
                    </div>
                    <Button onClick={handleNextPickup} size="lg">
                      Next Pickup
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            /* Pending Pickups List */
            <Card>
              <CardHeader>
                <CardTitle>Available Pickups</CardTitle>
                <CardDescription>Select a pickup to start delivery</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingPickups.map((pickup) => (
                    <div key={pickup.id} className="p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-medium text-foreground">{pickup.type}</p>
                          <p className="text-sm text-muted-foreground">{pickup.quantity}</p>
                        </div>
                        <Badge variant="secondary">{pickup.payment}</Badge>
                      </div>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-primary" />
                          <span className="text-muted-foreground">From:</span>
                          <span className="text-foreground">{pickup.donor}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 rounded-full bg-accent" />
                          <span className="text-muted-foreground">To:</span>
                          <span className="text-foreground">{pickup.recipient}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <Navigation className="w-3 h-3 text-muted-foreground" />
                          <span className="text-muted-foreground">{pickup.distance}</span>
                        </div>
                      </div>

                      {/* OTP Required Badge */}
                      <div className="flex items-center gap-1 text-xs text-primary mb-4">
                        <Shield className="h-3 w-3" />
                        <span>OTP verification required at pickup & delivery</span>
                      </div>
                      
                      <Button 
                        onClick={() => handleAcceptPickup(pickup)} 
                        className="w-full"
                      >
                        Accept Pickup
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}
